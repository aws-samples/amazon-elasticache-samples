# L2 KV cache savings report

## Executive summary

- Trace: 2 node(s), 2 rank(s), 0.02 h window, 196,112 computed prefill tokens.
- Ceiling (inf): token hit rate 60.7%, 114,896 tokens served from L2.
- Recommended capacity: inf (smallest capacity reaching 90% of the ceiling's beneficial saved tokens); token hit rate 60.7%.
- At inf: 23.0 replica-seconds of prefill saved in the window; mean TTFT saved per hit chunk 12.3 ms (Per-hit TTFT math: each hit is scored alone, without queueing or write stalls; not predictive of measured TTFT.)
- Bandwidth and write-cost model at inf (model estimate, not a measurement): TTFT change per lookup run with LMCache-like fetching p50 +178.9 ms, p90 +1.12 s; with kvtrace-ideal fetching (skip slow hits) p50 +1.5 ms, p90 +2.4 ms. 100.0% of hit chunks are slower to fetch than to recompute.
- Warning: the model predicts that L2 makes TTFT WORSE with LMCache-like fetching (p50 and p90 increase). The TTFT saved figures above score each hit alone and do not apply under this load.
- Missing inputs (some figures omitted): --gpu-cost-per-hour or --replica-cost-per-hour (no default price; dollar figures omitted); --prefill-time-fraction (or engine prefill/decode time metrics)

## Hit rate and savings by capacity

| Capacity | Lookups | Hits | Chunk hit rate | Token hit rate | Saved tokens | Same-node hit tokens | Cross-node hit tokens | Evictions | Peak used | Non-beneficial hits | Replica-h saved | Gross $ saved / month | Net $ / month (L2 price only) | Break-even $/GB-h (gross) | Throughput gain (upper bound) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 16KiB | 2,978 | 44 | 1.5% | 1.5% | 2,768 | 0 | 2,768 | 2,898 | 16.0 KiB | 0 | 0.000 | - | - | - | - |
| 64KiB | 2,978 | 203 | 6.8% | 6.8% | 12,880 | 6,192 | 6,688 | 2,615 | 64.0 KiB | 0 | 0.001 | - | - | - | - |
| inf | 2,978 | 1,800 | 60.4% | 60.7% | 114,896 | 102,720 | 12,176 | 0 | 589.0 KiB | 0 | 0.006 | - | - | - | - |

## Bandwidth and write-cost model (model estimates, not measurements)

TTFT delta = TTFT with L2 minus TTFT without L2, per lookup run (negative = faster). LMCache-like fetches every hit; kvtrace-ideal fetches only when that is faster than recomputing. Each node's L2 traffic queues on its own link; saves can block the request (blocking mode) and slow the host (stall per GB written).

| Capacity | Node | TTFT delta p50 / p90 (LMCache-like) | TTFT delta p50 / p90 (ideal) | Runs slower (LMCache-like) | Hits slower than recompute (LMCache-like) | Link utilization (LMCache-like) | Queue wait mean / p99 (LMCache-like) | Read MB/s | Write MB/s |
|---|---|---|---|---|---|---|---|---|---|
| 16KiB | all | +2.0 ms / +4.6 ms | +1.9 ms / +4.5 ms | 257 of 257 | 100.0% | - | - | 0.0 | 0.0 |
| 16KiB | node0 | - | - | - | - | lookup 0.2%, read 2.0%, write 75.6% | lookup 0.0 ms / 0.0 ms, read 0.0 ms / 0.0 ms, write 666.5 ms / 3.13 s | 0.0 | 0.0 |
| 16KiB | node1 | - | - | - | - | lookup 0.2%, read 0.4%, write 85.4% | lookup 0.0 ms / 0.0 ms, read 0.0 ms / 0.0 ms, write 1.67 s / 8.09 s | 0.0 | 0.0 |
| 64KiB | all | +2.0 ms / +87.7 ms | +1.8 ms / +4.2 ms | 257 of 257 | 100.0% | - | - | 0.0 | 0.0 |
| 64KiB | node0 | - | - | - | - | lookup 0.2%, read 6.8%, write 69.7% | lookup 0.0 ms / 0.0 ms, read 0.0 ms / 0.0 ms, write 501.8 ms / 2.10 s | 0.0 | 0.0 |
| 64KiB | node1 | - | - | - | - | lookup 0.2%, read 4.3%, write 81.1% | lookup 0.0 ms / 0.0 ms, read 19.6 ms / 196.3 ms, write 1.59 s / 7.96 s | 0.0 | 0.0 |
| inf | all | +178.9 ms / +1.12 s | +1.5 ms / +2.4 ms | 257 of 257 | 100.0% | - | - | 0.0 | 0.0 |
| inf | node0 | - | - | - | - | lookup 0.2%, read 45.5%, write 32.2% | lookup 0.0 ms / 0.0 ms, read 108.0 ms / 720.3 ms, write 8.3 ms / 196.3 ms | 0.0 | 0.0 |
| inf | node1 | - | - | - | - | lookup 0.2%, read 53.5%, write 32.6% | lookup 0.0 ms / 0.0 ms, read 462.4 ms / 2.58 s, write 0.0 ms / 0.0 ms | 0.0 | 0.0 |

| Input | Value |
|---|---|
| Link per node | read 0.0001 Gbit/s, write 0.0001 Gbit/s |
| Fixed cost per fetch | 2 ms |
| L2 check per lookup run (serialized per node) | 1 ms |
| Write mode | async |
| Host stall per GB written | 1e+06 ms |
| Delay per request per GB/s written | 100000 ms |
| Prefill model | 5,000 tokens/s per node, linear |

## Per-model breakdown

| Capacity | Model | Lookups | Hits | Saved tokens | Token hit rate |
|---|---|---|---|---|---|
| 16KiB | m | 2,978 | 44 | 2,768 | 1.5% |
| 64KiB | m | 2,978 | 203 | 12,880 | 6.8% |
| inf | m | 2,978 | 1,800 | 114,896 | 60.7% |

## Assumptions and inputs

| Input | Value |
|---|---|
| Chunk tokens | 64 |
| KV bytes per token | 8 |
| Eviction policy | lru |
| Write policy | store |
| Model filter | all |
| Prefill tokens/s per request (TTFT, fetch-or-recompute test) | 5,000 (missing) |
| Prefill tokens/s per replica (GPU time, dollars) | 5,000 (missing) |
| Replica cost per hour | missing (no default price) |
| L2 bandwidth | 100 Gbit/s |
| L2 round trip | 0.5 ms |
| L2 price per GB-hour | not given (break-even shown) |
| Prefill time fraction | missing |
| Break-even L2 bandwidth (full chunk) | 0.00 Gbit/s |

## Data quality

| Item | Value |
|---|---|
| Window | 1970-01-01 00:16:40 UTC to 1970-01-01 00:17:54 UTC |
| Nodes | node0, node1 |
| Ranks | node0:0, node1:0 |
| Models | m |
| Block sizes | 16 |
| Media | GPU |
| Gap batches (missing / recovered / unrecovered) | 0 / 0 / 0 |
| Publisher restarts | 0 |
| Decode errors / unknown events / bad events | 0 / 0 / 0 |
| Computed tokens | 196,112 |
| Load-back tokens (host tier to GPU) | 0 |
| Total stored tokens (all media) | 196,112 |
| Decode tokens (blocks filled by generation, not prefill) | 0 |
| Unknown parents anchored on their own chunk grid | 0 |
| Computed tokens on anchored (shifted) chunk grids | 0 |
| Unaligned tokens (unknown prefix depth, excluded) | 0 |
| Tail tokens (partial chunks, not cacheable) | 6,720 |
| Removals of unknown blocks | 0 |
| Events skipped for block size not dividing the chunk size | 0 |
| Unreadable lines / damaged segment files | 0 / 0 |

## Caveats

- The trace shows what the engines actually computed. The simulation assumes the same requests, arriving at the same times, would have looked up an L2 tier; it does not model changes in scheduling, batching or routing caused by faster prefill.
- One L2 is shared by every node in the trace. Hits written by another node count as cross-node hits.
- L2 lookups follow LMCache semantics: fixed-size chunks, longest-prefix retrieval, and no partial (tail) chunks.
- Lookup runs approximate requests. A run is one prefill (possibly split by chunked prefill) on one rank. vLLM decode blocks (one-block continuations) are counted as decode tokens; on other engines, decode-time blocks the engine stores are counted as computed blocks.
- Decode detection is a heuristic: on vLLM nodes, a genuine one-block prefill continuation (for example a short follow-up turn) within the decode window is counted as decode, so computed prefill tokens and L2 savings can be slightly understated.
- Chains under a parent cached before recording began (anchored parents) use a chunk grid that starts at that parent, shifted from the engine's absolute grid by its unknown depth. Their chunk keys agree across nodes, but chunk boundaries (and so tail tokens) can differ from what LMCache would use; see anchored tokens in the data-quality table.
- Time and dollar figures depend on the prefill throughput input; per-replica throughput varies with batch size, sequence length and hardware.
- The TTFT figures (TTFT saved per hit chunk, TTFT change per run) score each hit alone. They ignore queueing and write stalls. They do not predict measured TTFT.
- The fetch-or-recompute test (beneficial hits, GPU time and dollars) charges one L2 round trip per hit chunk. The TTFT change per run charges one round trip per run, because a run fetches its chunks together. For runs of many chunks, the test can call a hit not beneficial that the per-run figure counts as faster.
- Dollar savings are gross: they count only the GPU prefill time that L2 hits remove. The net figure subtracts only the L2 price per GB-hour x capacity x hours. It leaves out node granularity (whole cache nodes), replication and drain-buffer memory overhead, and network cost. GPU time saved does not subtract the fetch wait, because the GPU can do other work during a fetch; the fetch wait affects TTFT only.
- There is no default GPU price. Without --gpu-cost-per-hour or --replica-cost-per-hour, the report shows no dollar figures.
- The throughput gain is an upper bound: it assumes the replica is compute-bound and that the freed prefill time is fully reused for other work.
- The bandwidth and write-cost section (when the simulation ran with --contention on) is a model estimate, not a measurement: one FIFO link queue per node, a fixed fetch cost, a prefill-rate model and an optional host-stall knob. It does not model engine queueing, batching or decode (TPOT) effects.
- Values estimated from engine metrics are approximate. Prefill tokens/s = (prompt tokens - prompt tokens served from the GPU prefix cache, when reported) / sum of per-request prefill time: concurrent requests overlap in time, so the estimate can be off by the batch concurrency. The prefill fraction is a share of request time, not of GPU busy time. Pass measured values when you have them.
- The per-request prefill rate above is used for TTFT. For GPU time and dollars, the replica rate is --prefill-tokens-per-sec, or the per-request rate x the mean of vllm:num_requests_running (time-weighted over the window; the mean of the scrapes for an older sim.json). Running requests include requests in decode, so this replica rate is approximate.
- lookup time = store-event time: no per-request prefill rate (give --prefill-tokens-per-sec-per-request or record request_prefill_time metrics), so a lookup sees writes of requests that were still in prefill
- L2 is one global LRU of whole chunks with no allocator, segment or drain-buffer overhead: every byte of capacity holds chunk data. Set --l2-per-key-overhead-bytes and --l2-usable-fraction to model them
