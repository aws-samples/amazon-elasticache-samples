# L2 KV cache savings report

## Executive summary

- Trace: 2 node(s), 2 rank(s), 0.02 h window, 196,112 computed prefill tokens.
- Ceiling (inf): token hit rate 60.7%, 114,896 tokens served from L2.
- Recommended capacity: inf (smallest capacity reaching 90% of the ceiling's beneficial saved tokens); token hit rate 60.7%.
- At inf: 11.5 replica-seconds of prefill saved in the window; mean TTFT saved per hit chunk 5.9 ms (Per-hit TTFT math: each hit is scored alone, without queueing or write stalls; not predictive of measured TTFT.)
- Estimated gross GPU savings: $10,916.03 per month.
- Warning: the trace window is shorter than 1 hour, so per-month figures are a rough extrapolation. Record for longer.
- Break-even L2 price (from gross savings): $196.38 per GB-hour.

## Hit rate and savings by capacity

| Capacity | Lookups | Hits | Chunk hit rate | Token hit rate | Saved tokens | Same-node hit tokens | Cross-node hit tokens | Evictions | Peak used | Non-beneficial hits | Replica-h saved | Gross $ saved / month | Net $ / month (L2 price only) | Break-even $/GB-h (gross) | Throughput gain (upper bound) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1MiB | 2,978 | 40 | 1.3% | 1.4% | 2,560 | 0 | 2,560 | 2,922 | 1.0 MiB | 0 | 0.000 | $243.22 | - | $322.16 | 0.3% |
| 16MiB | 2,978 | 746 | 25.1% | 25.1% | 47,472 | 34,912 | 12,560 | 1,943 | 16.0 MiB | 0 | 0.001 | $4,510.22 | - | $373.37 | 6.4% |
| inf | 2,978 | 1,800 | 60.4% | 60.7% | 114,896 | 102,720 | 12,176 | 0 | 73.6 MiB | 0 | 0.003 | $10,916.03 | - | $196.38 | 17.2% |

## Per-model breakdown

| Capacity | Model | Lookups | Hits | Saved tokens | Token hit rate |
|---|---|---|---|---|---|
| 1MiB | <script>alert(1)</script> | 2,978 | 40 | 2,560 | 1.4% |
| 16MiB | <script>alert(1)</script> | 2,978 | 746 | 47,472 | 25.1% |
| inf | <script>alert(1)</script> | 2,978 | 1,800 | 114,896 | 60.7% |

## Assumptions and inputs

| Input | Value |
|---|---|
| Chunk tokens | 64 |
| KV bytes per token | 1,024 |
| Eviction policy | lru |
| Write policy | store |
| Model filter | all |
| Prefill tokens/s per request (TTFT, fetch-or-recompute test) | 10,000 (missing) |
| Prefill tokens/s per replica (GPU time, dollars) | 10,000 (input) |
| Replica cost per hour | $98.32 (missing) |
| L2 bandwidth | 100 Gbit/s |
| L2 round trip | 0.5 ms |
| L2 price per GB-hour | not given (break-even shown) |
| Prefill time fraction | 25.0% (input) |
| Break-even L2 bandwidth (full chunk) | 0.09 Gbit/s |

## Data quality

| Item | Value |
|---|---|
| Window | 1970-01-01 00:16:40 UTC to 1970-01-01 00:17:54 UTC |
| Nodes | node0, node1 |
| Ranks | node0:0, node1:0 |
| Models | <script>alert(1)</script> |
| Block sizes | 16 |
| Media | GPU |
| Gap batches (missing / recovered / unrecovered) | 0 / 0 / 0 |
| Publisher restarts | 0 |
| Decode errors / unknown events / bad events | 0 / 0 / 0 |
| Computed tokens | 196,112 |
| Load-back tokens (host tier to GPU) | 0 |
| Total stored tokens (all media) | 196,112 |
| Decode tokens (blocks filled by generation, not prefill) | 0 |
| Unknown parents anchored on their own chunk grid | 0 |
| Computed tokens on anchored (shifted) chunk grids | 0 |
| Unaligned tokens (unknown prefix depth, excluded) | 0 |
| Tail tokens (partial chunks, not cacheable) | 6,720 |
| Removals of unknown blocks | 0 |
| Events skipped for block size not dividing the chunk size | 0 |
| Unreadable lines / damaged segment files | 0 / 0 |

## Caveats

- The trace shows what the engines actually computed. The simulation assumes the same requests, arriving at the same times, would have looked up an L2 tier; it does not model changes in scheduling, batching or routing caused by faster prefill.
- One L2 is shared by every node in the trace. Hits written by another node count as cross-node hits.
- L2 lookups follow LMCache semantics: fixed-size chunks, longest-prefix retrieval, and no partial (tail) chunks.
- Lookup runs approximate requests. A run is one prefill (possibly split by chunked prefill) on one rank. vLLM decode blocks (one-block continuations) are counted as decode tokens; on other engines, decode-time blocks the engine stores are counted as computed blocks.
- Decode detection is a heuristic: on vLLM nodes, a genuine one-block prefill continuation (for example a short follow-up turn) within the decode window is counted as decode, so computed prefill tokens and L2 savings can be slightly understated.
- Chains under a parent cached before recording began (anchored parents) use a chunk grid that starts at that parent, shifted from the engine's absolute grid by its unknown depth. Their chunk keys agree across nodes, but chunk boundaries (and so tail tokens) can differ from what LMCache would use; see anchored tokens in the data-quality table.
- Time and dollar figures depend on the prefill throughput input; per-replica throughput varies with batch size, sequence length and hardware.
- The TTFT figures (TTFT saved per hit chunk, TTFT change per run) score each hit alone. They ignore queueing and write stalls. They do not predict measured TTFT.
- The fetch-or-recompute test (beneficial hits, GPU time and dollars) charges one L2 round trip per hit chunk. The TTFT change per run charges one round trip per run, because a run fetches its chunks together. For runs of many chunks, the test can call a hit not beneficial that the per-run figure counts as faster.
- Dollar savings are gross: they count only the GPU prefill time that L2 hits remove. The net figure subtracts only the L2 price per GB-hour x capacity x hours. It leaves out node granularity (whole cache nodes), replication and drain-buffer memory overhead, and network cost. GPU time saved does not subtract the fetch wait, because the GPU can do other work during a fetch; the fetch wait affects TTFT only.
- There is no default GPU price. Without --gpu-cost-per-hour or --replica-cost-per-hour, the report shows no dollar figures.
- The throughput gain is an upper bound: it assumes the replica is compute-bound and that the freed prefill time is fully reused for other work.
- The bandwidth and write-cost section (when the simulation ran with --contention on) is a model estimate, not a measurement: one FIFO link queue per node, a fixed fetch cost, a prefill-rate model and an optional host-stall knob. It does not model engine queueing, batching or decode (TPOT) effects.
- Values estimated from engine metrics are approximate. Prefill tokens/s = (prompt tokens - prompt tokens served from the GPU prefix cache, when reported) / sum of per-request prefill time: concurrent requests overlap in time, so the estimate can be off by the batch concurrency. The prefill fraction is a share of request time, not of GPU busy time. Pass measured values when you have them.
- The per-request prefill rate above is used for TTFT. For GPU time and dollars, the replica rate is --prefill-tokens-per-sec, or the per-request rate x the mean of vllm:num_requests_running (time-weighted over the window; the mean of the scrapes for an older sim.json). Running requests include requests in decode, so this replica rate is approximate.
- lookup time = store-event time: no per-request prefill rate (give --prefill-tokens-per-sec-per-request or record request_prefill_time metrics), so a lookup sees writes of requests that were still in prefill
- L2 is one global LRU of whole chunks with no allocator, segment or drain-buffer overhead: every byte of capacity holds chunk data. Set --l2-per-key-overhead-bytes and --l2-usable-fraction to model them
